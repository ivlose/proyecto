<?php
require_once "vehiculo.php";

class Coche extends Vehiculo{

private $descuento;
private $numeroPuertas;

	public function __construct($nombre,$antiguedad,$matricula,$precio,$descuento,$numeroPuertas){
		parent::__construct($nombre,$antiguedad,$matricula,$precio);
			$this->descuento=$descuento;
			$this->numeroPuertas=$numeroPuertas;
		
	}

	public function generarInformacionCoche(){
		$cadena=parent::generarInformacion().
		"Descuento:".$this->descuento."<br>".
	 	"Numero Puertas:".$this->numeroPuertas."<br>";
		return $cadena;
	}

	public function calcularPrecio(){
		$precioFinal=$this->precio-($this->descuento*$this->precio/100);
		return $precioFinal;
	}

}

?>