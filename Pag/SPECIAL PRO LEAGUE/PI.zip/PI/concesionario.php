<?php
require_once "coche.php";
class Concesionario{

private $vehiculos;
private $valor;

public function __construct($vehiculos){
		$this->vehiculos=$vehiculos;
	}

public function listarVehiculos(){
	$cadenaVehiculos="";
	for ($i=0; $i <sizeof($this->vehiculos); $i++) { 
		$cadenaVehiculos=$cadenaVehiculos.$this->vehiculos[$i]->generarInformacionCoche();
	}
	return $cadenaVehiculos;
}




}

?>