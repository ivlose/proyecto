<?php

	function load_template($title='Sin Titulo'){

		//cargo la estructura de la página por defecto page.php y la guardo en $pagina
		$pagina = load_page('vista/pagina.php');

		//actualización del TITULO de la página por defecto
		//1. reemplazo lo que hay en $titulo (parametro entrada) por la etiqueta #TITLE# que aparece en $pagina
		$pagina = replace_content('/\#TITLE\#/ms' ,$title , $pagina);	

		//Ya tengo mi página guardada en la variable $pagina y la devuelvo
		return $pagina;
	}

    function load_page($page){
		return file_get_contents($page);
	}
	
	function view_page($html){
		echo $html;
	}

	function replace_content($in='/\#CONTENIDO\#/ms', $out,$pagina){
		 return preg_replace($in, $out, $pagina);	 	
	}
	?>