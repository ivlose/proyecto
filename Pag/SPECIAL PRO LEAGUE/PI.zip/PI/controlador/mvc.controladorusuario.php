<?php

require 'modelo/usuario.class.php';
require 'generadorPagina.php';

class mvc_controller {


   function insertar($nick, $nombre, $apellido, $email, $contrasenya){
		$usuario = new Usuario();	
		//carga la plantilla 
		$pagina=load_template();				

		    $registrado = $usuario->insertarUsuario($nick, $nombre, $apellido, $email, $contrasenya);	
		    echo "registrado" . $registrado. "<br>";		   
	   		if($registrado){//si existen registros carga el modulo  en memoria y rellena con los datos 
						echo "Esta registrado<br>";
						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{//si no existen datos -> muestra mensaje de error
	   				echo "No Esta registrado<br>";
	   				$contenido = load_page('vista/modulos/m.registro2.php');	
		   			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$contenido .'<h1>Ha habido un error en la inserción</h1>' , $pagina);	
	   		}		
		view_page($pagina);
   }


   function principal(){
		$pagina=load_template('SPECIAL PRO LEAGUE');
		//en $html guardo el módulo principal				
		$html = load_page('vista/modulos/m.principal.php');
		//reemplazo la cadena #CONTENIDO# del $pagina por el $html de la página principal y guardo
		//la pagina resultante en $pagina
		$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		//muestro la página
		view_page($pagina);
   }


   function lol(){
		$pagina=load_template('LOL');				
		$html = load_page('vista/modulos/m.lol.php');
		$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		view_page($pagina);
   }

    function counter(){
		$pagina=load_template('COUNTER');				
		$html = load_page('vista/modulos/m.counter.php');
		$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		view_page($pagina);
   }

    function counterg(){
		$pagina=load_template('COUNTERG');				
		$html = load_page('vista/modulos/m.counterg.php');
		$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		view_page($pagina);
   }
   
	function minecraft(){
		$pagina=load_template('MINECRAFT');				
		$html = load_page('vista/modulos/m.minecraft.php');
		$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		view_page($pagina);
   }
   
	function registro($contrasenya){
		echo "Estamos en la funcion registro </br>";
		$pagina=load_template('REGISTRO');				
		$html = load_page('vista/modulos/m.registro2.php');
		
		if(isset($contrasenya)){

			$pagina = replace_content('/\#CONTENIDO\#/ms' ,"<h1>Ha habido un error</h1>".$html , $pagina);
		}else{ 
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		}
		view_page($pagina);
   }
   


}
?>