<?php
session_start();
require 'modelo/usuario.class.php';
require 'modelo/administrador.class.php';
require 'generadorPagina.php';

class mvc_controller {


   function insertar($nick, $nombre, $apellido, $email, $contrasenya){
		$usuario = new Usuario();	
		//carga la plantilla 
		$pagina=load_template();				

		    $registrado = $usuario->insertarUsuario($nick, $nombre, $apellido, $email, $contrasenya);			   
	   		if($registrado){//si existen registros carga el modulo  en memoria y rellena con los datos 
						echo "Esta registrado<br>";
						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{//si no existen datos -> muestra mensaje de error
	   				echo "No Esta registrado<br>";
	   				$contenido = load_page('vista/modulos/m.registro2.php');	
		   			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$contenido .'<h1>Ha habido un error en la inserción</h1>' , $pagina);	
	   		}		
		view_page($pagina);
   }

    function insertarEquipos($nombree,$contrasenyae){
		$equipo = new Usuario();	 
		$pagina=load_template();				
		    $nuevoequipo = $equipo->insertarEquipo($nombree, $contrasenyae);	
		    echo $nuevoequipo;		   
	   		if($nuevoequipo){
						echo "Equipo creado<br>";
						$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						echo $_SESSION["nick"];
						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{
	   				echo "No se ha podido crear el equipo<br>";
	   				$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
					$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
					echo $_SESSION["nick"];
	   				$contenido = load_page('vista/modulos/m.equipos.php');	
		   			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$contenido .'<h1>Ha habido un error en la inserción</h1>' , $pagina);	
	   		}		
		view_page($pagina);
   }


   function login($nickb,$contrasenyab){
		$usuario = new Usuario();	
		$pagina=load_template();				

		    $logeado = $usuario->loginUsuario($nickb, $contrasenyab);	
	   		if($logeado){
						$_SESSION["nick"] = $nickb;
						if ($nickb == "tmj22") {
						$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						echo $_SESSION["nick"];
						$contenido = load_page('vista/modulos/m.admin.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);
						}else{
						$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						echo $_SESSION["nick"];
						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);
						}	
	   		}else{
	   				echo "No esta logeado<br>";
	   					$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);

						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}		
		view_page($pagina);
   }

   function principal(){
		$pagina=load_template('SPECIAL PRO LEAGUE');			
		
		if (isset($_SESSION['nick'])) {
			echo $_SESSION['nick'];
			$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}else{
			$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}

		$contenido = load_page('vista/modulos/m.principal.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		view_page($pagina);
   }


   function lol(){
		$pagina=load_template('LOL');			
		if (isset($_SESSION['nick'])) {
			echo $_SESSION['nick'];
			$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}else{
			$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}
		
		$contenido = load_page('vista/modulos/m.lol.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		view_page($pagina);
   }

    function counter(){
		$pagina=load_template('COUNTER');			
		if (isset($_SESSION['nick'])) {
			echo $_SESSION['nick'];
			$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}else{
			$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}

		$contenido = load_page('vista/modulos/m.counter.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		view_page($pagina);
   }

    function counterg(){
		$pagina=load_template('COUNTER G');			
		if (isset($_SESSION['nick'])) {
			echo $_SESSION['nick'];
			$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}else{
			$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}

		$contenido = load_page('vista/modulos/m.counterg.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		view_page($pagina);
   }
   
	function minecraft(){
		$pagina=load_template('MINECRAFT');			
		if (isset($_SESSION['nick'])) {
			echo $_SESSION['nick'];
			$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}else{
			$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		}

		$contenido = load_page('vista/modulos/m.minecraft.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		view_page($pagina);
   }
////////////////////PERFIL///////
    function perfil($nick)
   {
		$usuario = new Usuario();	
		$pagina=load_template("PERFIL");				
		  ob_start();
		   $tsArray = $usuario->mostrarPerfil($nick);		   
	   		if($tsArray!=''){
						$titulo = 'Resultado de busqueda por "'.$nick.'" ';		
			  			include 'vista/modulos/m.perfil.php';
						$contenido = ob_get_clean();	
						$cabecera = load_page('vista/modulos/m.cabecerausuario.php');
						echo $_SESSION["nick"];	
					$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido , $pagina);		
	   		}		
		view_page($pagina);
   }
///////////////////////////
   
	function registro($contrasenya){
		$pagina=load_template('REGISTRO');			
		$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		
		$contenido = load_page('vista/modulos/m.registro2.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		
		if(isset($contrasenya)){
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,"<h1>Ha habido un error</h1>".$html , $pagina);
		}else{ 
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		}
		view_page($pagina);
   }
   
	function equipos($contrasenyaequipo){
		$pagina=load_template('EQUIPOS');	
		$cabecera = load_page('vista/modulos/m.cabecerausuario.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		echo $_SESSION["nick"];
		$contenido = load_page('vista/modulos/m.equipos.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		
		if(isset($contrasenyaequipo)){
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,"<h1>Ha habido un error</h1>".$html , $pagina);
		}else{ 
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		}
		view_page($pagina);
   }
   

////////////FUNCIONES DE ADMINISTRADOR/////////////////
   function torneos($nombre, $fecha, $idJuego, $contrasenyat){
		$administrador = new Administrador();	
		$pagina=load_template();				
		    $creatorneo = $administrador->insertarTorneo($nombre, $fecha, $idJuego, $contrasenyat);			   
	   		if($creatorneo){
						echo "Se ha creado el torneo<br>";
						$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						echo $_SESSION["nick"];
						$contenido = load_page('vista/modulos/m.admin.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{
	   				echo "Ha habido un error<br>";
	   				$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
					$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
					echo $_SESSION["nick"];
					$contenido = load_page('vista/modulos/m.admin.php');	
					$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}		
		view_page($pagina);
   }

	function crear($contrasenyat){
		$pagina=load_template('CREAR TORNEOS');			
		$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		
		$contenido = load_page('vista/modulos/m.creartorneo.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		
		if(isset($contrasenyat)){
			echo "HA HABIDO UN ERROR";
		$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		
		$contenido = load_page('vista/modulos/m.creartorneo.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		}else{ 

					$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
					$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		
					$contenido = load_page('vista/modulos/m.admin.php');	
					$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		}
		view_page($pagina);
   }
   

   function borrar($nombre){
		$administrador = new Administrador();	
		$pagina=load_template();				

		    $borrar = $administrador->borrarTorneo($nombre);
		    echo "BORRAR";			   
	   		if($borrar){ 
						echo "Se ha borrado el torneo<br>";
						$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
						$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
						echo $_SESSION["nick"];
						$contenido = load_page('vista/modulos/m.admin.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{
	   				echo "Ha habido un error<br>";
	   				$cabecera = load_page('vista/modulos/m.cabeceraadmin.php');	
					$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
					echo $_SESSION["nick"];
					$contenido = load_page('vista/modulos/m.admin.php');	
					$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}		
		view_page($pagina);
   }



}
?>