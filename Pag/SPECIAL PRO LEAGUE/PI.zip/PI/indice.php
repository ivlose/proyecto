<?php
	session_start();
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
	require 'controlador/mvc.controladorusuario.php';
	//require 'controlador/mvc.controladoradministrador.php';
	$mvc = new mvc_controller();

	if( $_GET['action'] == 'registro' ) 
	{	
			$mvc->registro(null);	
	}

	else if( $_GET['action'] == 'equipos' ) 
	{	
			$mvc->equipos(null);	
	}

	else if( $_GET['action'] == 'creartorneo' ) 
	{	
			$mvc->crear(null);	
	}

	//JUEGOS/////
	else if( $_GET['action'] == 'lol' ) 
	{
			$mvc->lol();	
	}
	else if( $_GET['action'] == 'minecraft' ) 
	{
			$mvc->minecraft();	
	}
	else if( $_GET['action'] == 'counterg' ) 
	{
			$mvc->counterg();
	}

	else if( $_GET['action'] == 'counter' ) 
	{
			$mvc->counter();
	}
 ////////

////PERFIL USUARIO//
	else if( $_GET['action'] == 'perfil' ) 
	{
			$mvc->perfil($_SESSION['nick']);
	}
///
	else if( isset($_POST['nick']) && 
			 isset($_POST['nombre']) &&
			 isset($_POST['apellido']) &&
			 isset($_POST['email']) &&
			 isset($_POST['contrasenya'])
			 )
	{
		if($_POST['contrasenya']===$_POST['contrasenya2']){
			$mvc->insertar($_POST['nick'], $_POST['nombre'], $_POST['apellido'], $_POST['email'], md5($_POST['contrasenya']));
		}else{
			$mvc->registro($_POST['contrasenya']);	
		}
	}

	else if( isset($_POST['nombreequipo']) &&
			 isset($_POST['contrasenyaequipo'])
			 )
	{
		if($_POST['contrasenyaequipo']===$_POST['contrasenyaequipo2']){

			$mvc->insertarEquipos($_POST['nombreequipo'],md5($_POST['contrasenyaequipo']));
		}else{

			$mvc->equipos($_POST['contrasenyaequipo']);	
		}
	}
//////LOGIN////
	else if( isset($_POST['nickb']) &&
			 isset($_POST['contrasenyab'])){
	$mvc->login($_POST['nickb'],$_POST['contrasenyab']);
}

///CREARTORNEO////////
else if( isset($_POST['nombret']) && 
			 isset($_POST['fechat']) &&
			 isset($_POST['idjuego']) &&
			 isset($_POST['contrasenyat'])
			 )
	{
		if($_POST['contrasenyat']===$_POST['contrasenyat2']){
			$mvc->torneos($_POST['nombret'], $_POST['fechat'], $_POST['idjuego'], md5($_POST['contrasenyat']));
		}else{
			$mvc->crear($_POST['contrasenyat']);	
		}
	}
//////BORRAR TORNEO////
	else if( isset($_POST['borrart'])){
	$mvc->borrar($_POST['borrart']);
}
/////PRINCIPAL////
	else 
	{	
		$mvc->principal();
	}

	

?>