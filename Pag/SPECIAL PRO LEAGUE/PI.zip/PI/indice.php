<?php

	error_reporting(E_ERROR | E_WARNING | E_PARSE);
	require 'controlador/mvc.controladorusuario.php';

	$mvc = new mvc_controller();

	if( $_GET['action'] == 'registro' ) 
	{	
			$mvc->registro(null);	
	}
	else if( $_GET['action'] == 'lol' ) 
	{
			$mvc->lol();	
	}
	else if( $_GET['action'] == 'minecraft' ) 
	{
			$mvc->minecraft();	
	}
	else if( $_GET['action'] == 'counterg' ) 
	{
			$mvc->counterg();
	}

	else if( $_GET['action'] == 'counter' ) 
	{
			$mvc->counter();
	}

	else if( isset($_POST['nick']) && 
			 isset($_POST['nombre']) &&
			 isset($_POST['apellido']) &&
			 isset($_POST['email']) &&
			 isset($_POST['contrasenya'])
			 )
	{
		if($_POST['contrasenya']===$_POST['contrasenya2']){
			echo "Llamando a insertar<br>";
			$mvc->insertar($_POST['nick'], $_POST['nombre'], $_POST['apellido'], $_POST['email'], $_POST['contrasenya']);
		}else{
			$mvc->registro($_POST['contrasenya']);	
		}
	}

	else 
	{	
		echo "Llamando a principal<br>";
		$mvc->principal();
	}

	

?>