<?php
require_once "bd.class.php";

class Usuario extends Database{


function insertarUsuario($nick, $nombre, $apellido, $email, $contrasenya)
	{
		$this->conectar();	
		$fecha = date('Y-m-d', time());
		echo $fecha;
		$sentencia = "INSERT INTO usuarios(nick,nombre,apellido,email,contrasenya,fecha) VALUES ('$nick', '$nombre', '$apellido', '$email', '$contrasenya', '$fecha')";	
		
		echo $sentencia. "<br>";
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}

	function loginUsuario($nick)
	{
		$this->conectar();	
		$sentencia = "SELECT COUNT(*) FROM usuarios WHERE nick=$_POST[nick] AND contrasenya=$_POST[contrasenya]";	
		echo $sentencia. "<br>";
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}


function borrarUsuario($id, $nick, $nombre, $apellido, $email, $contraseña, $fecha)
	{
		$this->conectar();	
		$sentencia = "DELETE FROM usuarios WHERE id=$id";
		echo $sentencia;	
		$query = $this->consulta("DELETE FROM usuarios WHERE id=$id");
		if($query)
		{		
			$this->disconnect();
			return true;
		}else{	
			$this->disconnect();
			return false;
		}			
	}



function buscarUsuario($id=NULL)
	{
		$this->conectar();		
		$query = $this->consulta("SELECT * FROM usuarios WHERE id='$id'");
 	    $this->disconnect();					
		if($this->numero_de_filas($query) > 0) 
		{		
				while ( $tsArray = $this->fetch_assoc($query) ) 
					$data[] = $tsArray;			
		
				return $data;
		}else
		{	
			return '';
		}			
	}




}

?>