<?php

require_once "coche.php";
require_once "concesionario.php";

$coche1=new Coche("coche1",3,"ASADAS",16000,20,5);
$cadena1=$coche1->generarInformacionCoche();
//echo $cadena1."<br>";

$coche2=new Coche("coche2",3,"FFF7UU",20000,25,3);
$cadena2=$coche2->generarInformacionCoche();
//echo $cadena2."<br>";

$coche3=new Coche("coche3",2,"POO4RR",15000,20,5);
$cadena3=$coche3->generarInformacionCoche();
//echo $cadena3."<br>";

$vehiculos=array($coche1,$coche2,$coche3);
$concesionario=new Concesionario($vehiculos);

$lista=$concesionario->listarVehiculos();
echo $lista;


?>