<?php

abstract class Vehiculo{

private $nombre;
private $antiguedad;
private $matricula;
private $precio;

	public function __construct($nombre,$antiguedad,$matricula,$precio){
		$this->nombre=$nombre;
		$this->antiguedad=$antiguedad;
		$this->matricula=$matricula;
		$this->precio=$precio;
	}

	public abstract function calcularPrecio();

	public function generarInformacion(){
		$cadena="Nombre:".$this->nombre."<br>".
	 	"Antiguedad:".$this->antiguedad."<br>".
	 	"Matricula:".$this->matricula."<br>".
	 	"Precio:".$this->precio."<br>";
		return $cadena;
	}

}

?>