<div id="contenedor">    
<a href="indice.php?action=registro"><IMG class="user" alt="Formulario Registro" SRC="vista/img/user.png"></a>  
<a href="indice.php?action=creartorneo"><input type="submit" value="creartorneo" id="botonPerfil"></a>
</div>
 
