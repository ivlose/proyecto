

<div class="logmod">
  <div class="logmod__wrapper">
    <div class="logmod__container">
      <ul class="logmod__tabs">
        <li data-tabtar="lgm-1"><a href="#">CREAR TORNEO</a></li>
        <li data-tabtar="lgm-2"><a href="#">BORRAR TORNEO</a></li>
      </ul>
      <div class="logmod__tab-wrapper">
      <div class="logmod__tab lgm-1">
      <div class="logmod__heading">
          <span class="logmod__heading-subtitle">Pon los datos <strong>del torneo</strong></span>
        </div>
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform" method="POST">

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nombre</label>
                <input class="string optional" name="nombret" maxlength="255" id="nick" placeholder="Nombre" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Fecha</label>
                <input class="string optional" name="fechat" maxlength="255" id="nombre" placeholder="Fecha" type="date" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">ID Juego</label>
                <input class="string optional" name="idjuego" maxlength="255" id="idjuego" placeholder="ID juego" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Contraseña</label>
                <input class="string optional" name="contrasenyat" maxlength="6" id="contrasenyat" placeholder="Contraseña" type="password" size="7" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Confirmar contraseña</label>
                <input class="string optional" name="contrasenyat2" maxlength="6" id="contrasenyat2" placeholder="Confirmar" type="password" size="7" />
              </div>
            </div>

            <div id="centrar" class="simform__actions">
              <input class="submit" name="Submit" type="submit" value="CREAR TORNEO" id="botonPerfil" />
            </div> 
          </form>
        </div> 
        
      </div>
      <div class="logmod__tab lgm-2">
        <div class="logmod__heading">
          <span class="logmod__heading-subtitle"> Pon el nombre del torneo <strong>que quieres borrar </strong></span>
        </div> 
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform" method="POST">
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nombre torneo</label>
                <input class="string optional" name="borrart" maxlength="255" id="borrart" placeholder="Torneo" type="text" size="50" />
              </div>
            </div>
            <div id="centrar" class="simform__actions">
              <input class="submit" name="Submit" type="submit" value="BORRAR" id="botonPerfil"/>
            </div> 
          </form>
        </div> 
        
          </div>
      </div>
    </div>
  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="vista/js/indexFormulario.js"></script>

    
    

