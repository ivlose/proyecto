

<div class="logmod">
  <div class="logmod__wrapper">
    <div class="logmod__container">
      <ul class="logmod__tabs">
        <li data-tabtar="lgm-2"><a href="#">INICIA</a></li>
        <li data-tabtar="lgm-1"><a href="#">REGISTRATE</a></li>
      </ul>
      <div class="logmod__tab-wrapper">
      <div class="logmod__tab lgm-1">
      <div class="logmod__heading">
          <span class="logmod__heading-subtitle">Pon tus datos personales <strong>para crearte una cuenta</strong></span>
        </div>
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform" method="POST">

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nick</label>
                <input class="string optional" name="nick" maxlength="255" id="nick" placeholder="Nick" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nombre</label>
                <input class="string optional" name="nombre" maxlength="255" id="nombre" placeholder="Nombre" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Apellido</label>
                <input class="string optional" name="apellido" maxlength="255" id="apellido" placeholder="Apellido" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Email</label>
                <input class="string optional" name="email" maxlength="255" id="email" placeholder="Email" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Contraseña</label>
                <input class="string optional" name="contrasenya" maxlength="6" id="contrasenya" placeholder="Contraseña" type="password" size="7" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Confirmar contraseña</label>
                <input class="string optional" name="contrasenya2" maxlength="6" id="contrasenya2" placeholder="Confirmar" type="password" size="7" />
              </div>
            </div>

            <div id="centrar" class="simform__actions">
              <input class="submit" name="Submit" type="submit" value="CREAR CUENTA" />
            </div> 
          </form>
        </div> 
        
      </div>
      <div class="logmod__tab lgm-2">
        <div class="logmod__heading">
          <span class="logmod__heading-subtitle"> Pon tu email y contraseña <strong>para iniciar sesion</strong></span>
        </div> 
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform">
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nick</label>
                <input class="string optional" name="nick" maxlength="255" id="nick" placeholder="Nick" type="text" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Contraseña</label>
                <input class="string optional" name="contrasenya" maxlength="6" id="contrasenya" placeholder="Contraseña" type="password" size="7" />
              </div>
            </div>
            <div class="simform__actions">
              <input class="sumbit" name="commit" type="sumbit" value="INICIAR SESION" />
              <span class="simform__actions-sidetext"><a class="special" role="link" href="#">Olvidaste tu contraseña?<br>Click Aqui</a></span>
            </div> 
          </form>
        </div> 
        
          </div>
      </div>
    </div>
  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="vista/js/indexFormulario.js"></script>

    
    
  </body>
</html>
