<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>#TITLE#</title>
    <script src="vista/style.css" type="text/javascript/css"></script>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="vista/css/style.css">
    
    <link rel="stylesheet" href="vista/css/normalizeFormulario.css">
    <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
    <link rel="stylesheet" type="text/css" href="vista/css/styleFormulario.css">
 <!-- LINK SLAIDERS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
  }

  #myCarousel{
    z-index: +1;
  }


</style>

</head>

<body>
<header>
<div id="wrapper"><!-- MARGEN COLOR  -->
        <div id="header">       
        
<a href="indice.php?action=registro"><IMG class="user"SRC="vista/img/user.png"></a>  
       
      </div>
      </div>
</div>

<a href="indice.php"><IMG class="logo"SRC="vista/img/gaming.png" height="50px" widht="50px"></a>
  
<div id="header2"></div>

</header>

<nav>
    <ul class="menu cf">
  <li><a href="indice.php?action=counter">COUNTER STRIKE SOURCE</a>
  </li>
  <li>
    <a href="indice.php?action=lol">LEAGUE OF LEGENDS</a>
  </li>
  <li><a href="indice.php?action=minecraft">MINECRAFT</a>
  </li>
  <li><a href="indice.php?action=counterg">COUNTER STRIKE GLOBAL OFENSIVE</a>
  </li>
</ul>
</nav>  
 <br>

#CONTENIDO#
<footer>

<div id="footer">

  <p>SPL</p>
  <p>.</p>


</div>



</footer>

  </body>
</html>
