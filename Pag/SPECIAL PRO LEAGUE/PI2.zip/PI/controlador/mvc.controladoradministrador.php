<?php

require 'modelo/administrador.class.php';
require 'generadorPagina.php';

class mvc_controlleradmin {


   function torneos($nombre, $fecha, $idJuego, $contrasenyat){
		$usuario = new Administrador();	
		$pagina=load_template();				
		    $creatorneo = $usuario->insertarUsuario($nombre, $fecha, $idJuego, $contrasenyat);			   
	   		if($creatorneo){
						echo "Se ha creado el torneo<br>";
						$contenido = load_page('vista/modulos/m.principal.php');	
						$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
	   		}else{
	   				echo "Ha habido un error<br>";
	   				$contenido = load_page('vista/modulos/m.registro2.php');	
		   			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$contenido .'<h1>Ha habido un error en la inserción</h1>' , $pagina);	
	   		}		
		view_page($pagina);
   }

	function crear(){
		$pagina=load_template('CREAR TORNEOS');			
		$cabecera = load_page('vista/modulos/m.cabecerainicial.php');	
		$pagina = replace_cabecera('/\#CABECERA\#/ms', $cabecera, $pagina);
		
		$contenido = load_page('vista/modulos/m.registro2.php');	
		$pagina = replace_content('/\#CONTENIDO\#/ms', $contenido, $pagina);	
		
		if(isset($contrasenyat)){
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,"<h1>Ha habido un error</h1>".$html , $pagina);
		}else{ 
			$pagina = replace_content('/\#CONTENIDO\#/ms' ,$html , $pagina);
		}
		view_page($pagina);
   }
   



}
?>