<?php
require_once "bd.class.php";

class Juego extends Database{

function insertarJuego($id, $juego, $genero, $descripcion)
	{
		$this->conectar();	
		$sentencia = "INSERT INTO juegos VALUES ('$id', '$juego', '$genero', '$descripcion')";
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();	
			return false;
		}
	}

function borrarJuego($id, $juego, $genero, $descripcion)
	{
		$this->conectar();	
		$sentencia = "DELETE FROM juegos WHERE id=$id";
		echo $sentencia;	
		$query = $this->consulta("DELETE FROM juegos WHERE id=$id");
		if($query)
		{		
			$this->disconnect();
			return true;
		}else{	
			$this->disconnect();
			return false;
		}			
	}

function buscarJuego($id=NULL)
	{
		$this->conectar();		
		$query = $this->consulta("SELECT * FROM juegos WHERE id='$id'");
 	    $this->disconnect();					
		if($this->numero_de_filas($query) > 0) 
		{		
				while ( $tsArray = $this->fetch_assoc($query) ) 
					$data[] = $tsArray;			
		
				return $data;
		}else
		{	
			return '';
		}			
	}

}

?>