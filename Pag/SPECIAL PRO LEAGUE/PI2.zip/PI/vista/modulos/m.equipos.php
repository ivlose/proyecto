

<div class="logmod">
  <div class="logmod__wrapper">
    <div class="logmod__container">
      <ul class="logmod__tabs">
        <li data-tabtar="lgm-2"><a href="#">UNETE A UN EQUIPO</a></li>
        <li data-tabtar="lgm-1"><a href="#">CREA UN EQUIPO</a></li>
      </ul>
      <div class="logmod__tab-wrapper">
      <div class="logmod__tab lgm-1">
      <div class="logmod__heading">
          <span class="logmod__heading-subtitle">Pon un nombre y una contraseña <strong>para tu equipo</strong></span>
        </div>
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform" method="POST">

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nombre</label>
                <input class="string optional" name="nombreequipo" maxlength="255" id="nombreequipo" placeholder="Nombre equipo" type="text" size="50" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Contraseña</label>
                <input class="string optional" name="contrasenyaequipo" maxlength="6" id="contrasenyaequipo" placeholder="Contraseña" type="password" size="7" />
              </div>
            </div>

            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Confirmar contraseña</label>
                <input class="string optional" name="contrasenyaequipo2" maxlength="6" id="contrasenyaequipo2" placeholder="Confirmar" type="password" size="7" />
              </div>
            </div>

            <div id="centrar" class="simform__actions">
              <input class="submit" name="Submit" type="submit" value="CREAR EQUIPO" id="botonPerfil"/>
            </div> 
          </form>
        </div> 
        
      </div>
      <div class="logmod__tab lgm-2">
        <div class="logmod__heading">
          <span class="logmod__heading-subtitle"> Pon el nombre y la contraseña <strong>del equipo al que quieres unirte</strong></span>
        </div> 
        <div class="logmod__form">
          <form accept-charset="utf-8" action="indice.php" class="simform" method="POST">
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Nombre</label>
                <input class="string optional" name="nickequipob" maxlength="255" id="nombrequipob" placeholder="Nombre" type="text" size="25" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Contraseña</label>
                <input class="string optional" name="contrasenyaequipob" maxlength="6" id="contrasenyaequipob" placeholder="Contraseña" type="password" size="7" />
              </div>
            </div>
            <div id="centrar" class="simform__actions">
              <input class="submit" name="Submit" type="submit" value="UNETE" id="botonPerfil"/>
            </div> 
          </form>
        </div> 
        
          </div>
      </div>
    </div>
  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="vista/js/indexFormulario.js"></script>

    
    
  </body>
</html>
