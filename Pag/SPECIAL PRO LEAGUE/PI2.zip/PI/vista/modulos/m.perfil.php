
<div class="t"><?php echo "PERFIL"; ?></div>		
    <table border="0" cellspacing="3" cellpadding="0" class="tabla" width="100%" contentEditable="true">
    	  <?php foreach ($tsArray as $data): ?>
		 <tr>
	    	<th>ID</th>
	    	<td><?php echo"<b>". $data['id']."<b>";?></td>
	    </tr>
	    <tr>
	    	<th>Nick</th>
	    	<td><?php echo"<b>". $data['nick']."<b>";?></td>
	    </tr>
	    <tr>	
	    	<th>Nombre </th>
	    	<td><?php echo"<b>". $data['nombre']."<b>";?></td>
	    </tr>
	    <tr>	
	    	<th>Apellido </th>
	    	<td><?php echo"<b>". $data['apellido']."<b>";?></td>
	    </tr>
	    <tr>	
		    <th>Email</th>
		    <td><?php echo"<b>". $data['email']."<b>";?></td>
		</tr>
		 <tr>   
		    <th>Fecha de registro</th>
		    <td><?php echo"<b>". $data['fecha']."<b>";?></td>
		 </tr>
	   <?php endforeach; ?>
	</table>		   