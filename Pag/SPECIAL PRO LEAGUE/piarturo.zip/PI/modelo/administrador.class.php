<?php
require_once "bd.class.php";
class Administrador extends Database{


function insertarTorneo($nombre, $fecha, $idjuego, $contrasenyat)
	{
		$this->conectar();	
		$sentencia = "INSERT INTO torneos(nombre,fecha,idJuego,contrasenya) VALUES ('$nombre', '$fecha', '$idjuego', '$contrasenyat')";	
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}

function borrarTorneo($nombre)
	{
		$this->conectar();	
		$sentencia = "DELETE FROM torneos WHERE nombre = '$nombre'";
		echo $sentencia;	
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}


}

?>