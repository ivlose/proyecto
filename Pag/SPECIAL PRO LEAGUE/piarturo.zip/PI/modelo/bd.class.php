<?php

class Database {

 private $conexion;
  
	public function conectar(){
		if(!isset($this->conexion))
		{
		  $this->conexion = (mysqli_connect("localhost","root","")) or die(mysql_error());
		  mysqli_select_db($this->conexion,"spl") or die(mysqli_error());		  
		}
	}	
/*$this->conexion = (mysqli_connect("	
ec2-52-39-144-168.us-west-2.compute.amazonaws.com:3306/spl","arturo","7lin987G")) or die(mysql_error());*/
	public function consulta($sql){
		$resultado = mysqli_query($this->conexion, $sql);
		if(mysqli_error($this->conexion)){
			echo mysqli_error($this->conexion);
		}
  		return $resultado; 
	}
	
	public function consultaLogin($sql){

		$resultado = mysqli_query($this->conexion, $sql);		
		$num_resultados = mysqli_num_rows($resultado);

		if(mysqli_error($this->conexion)){
			echo mysqli_error($this->conexion);
		}

  		return $num_resultados; 
	}
	

	function numero_de_filas($result){

		return mysqli_num_rows($result);
	}
	
	function fetch_assoc($result){

			return mysqli_fetch_assoc($result);
	}
	
	public function disconnect(){
		mysqli_close($this->conexion);
	}

}
?>