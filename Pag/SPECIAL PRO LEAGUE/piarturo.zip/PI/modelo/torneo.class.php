<?php
require_once "bd.class.php";

class Torneo extends Database{

function insertarTorneo($id, $nombre, $fecha, $idjuego, $contraseña, $servidor)
	{
		$this->conectar();	
		$sentencia = "INSERT INTO torneos VALUES ('$id', '$nombre', '$fecha', '$idjuego', '$contraseña', '$servidor')";
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();	
			return false;
		}
	}

function borrarTorneo($id, $nombre, $fecha, $idjuego, $contraseña, $servidor)
	{
		$this->conectar();	
		$sentencia = "DELETE FROM torneos WHERE id=$id";
		echo $sentencia;	
		$query = $this->consulta("DELETE FROM torneos WHERE id=$id");
		if($query)
		{		
			$this->disconnect();
			return true;
		}else{	
			$this->disconnect();
			return false;
		}			
	}

function buscarTorneo($id=NULL)
	{
		$this->conectar();		
		$query = $this->consulta("SELECT * FROM torneos WHERE id='$id'");
 	    $this->disconnect();					
		if($this->numero_de_filas($query) > 0) 
		{		
				while ( $tsArray = $this->fetch_assoc($query) ) 
					$data[] = $tsArray;			
		
				return $data;
		}else
		{	
			return '';
		}			
	}

}

?>