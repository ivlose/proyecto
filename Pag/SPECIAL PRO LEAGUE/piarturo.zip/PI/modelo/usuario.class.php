<?php
require_once "bd.class.php";
session_start();
class Usuario extends Database{


function insertarUsuario($nick, $nombre, $apellido, $email, $contrasenya)
	{
		$this->conectar();	
		$fecha = date('Y-m-d', time());
		$sentencia = "INSERT INTO usuarios(nick,nombre,apellido,email,contrasenya,fecha) VALUES ('$nick', '$nombre', '$apellido', '$email', '$contrasenya', '$fecha')";	
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}

	function loginUsuario($nickb,$contrasenyab)
	{
		$this->conectar();	
		$contrasenyab=($_POST['contrasenyab']);
		$nickb=$_POST['nickb'];
		$sentencia = "SELECT nick FROM usuarios WHERE nick = '$nickb' AND contrasenya = '$contrasenyab'";	
		if($this->consultaLogin($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}

	function mostrarPerfil($nick)
	{
		$this->conectar();		
		$query = $this->consulta("SELECT * FROM usuarios WHERE nick='$nick'");
		/*$query2 = $this->consulta("SELECT * FROM equipos WHERE lider='$nick'");*/
 	    $this->disconnect();
		if($this->numero_de_filas($query) > 0)
		{		
				while ( $tsArray = $this->fetch_assoc($query) ) 
					$data[] = $tsArray;			
				return $data;

		}else
		{	
			return '';
		}	
		/*  MOSTRAR EQUIPOS
				if($this->numero_de_filas($query2) > 0)
		{		
				while ( $tsArray2 = $this->fetch_assoc($query2) ) 
					$data2[] = $tsArray2;			
				return $data2;

		}else
		{	
			return '';
		}*/				


	}

	function insertarEquipo($nombree,$contrasenyae)
	{
		echo "INSERTAR EQUIPO";
		$this->conectar();	
		$lidere = $_SESSION['nick'];
		$sentencia = "INSERT INTO equipos(lider,puntuacion,nombre,contrasenya,fecha) VALUES ('$lidere',0,'$nombree','$contrasenyae',NOW())";
		if($query = $this->consulta($sentencia)){
			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();
			return false;
		}
	}


	function unirseEquipo($nombre,$contrasenyaequipo){

		$this->conectar();	
		// $idequipo=$_POST['idequipo'];
		// $contrasenyaequipo=$_POST['contrasenyaequipob'];
		$jugador=$_SESSION['nick'];
		$sentencia = "SELECT * FROM equipos WHERE nombre = '$nombre' and contrasenya = '$contrasenyaequipo'";	
		if($query = $this->consulta($sentencia)){
			$idequipobd = mysqli_fetch_array($query)[0];
			$sentencia = "SELECT idusuario FROM usuarios WHERE nombre = '$jugador'";
			if($queryUsuario = $this->consulta($sentencia)){
				$idusuariobd = mysqli_fetch_array($queryUsuario)[0];
				$sentencia = "INSERT INTO equiposusuarios(idusuario,idequipo) VALUES ('$idusuariobd','$idequipobd')";
				if($query = $this->consulta($sentencia)){	
				return true;
				}
			}

			$this->disconnect();	
			return true;
		}else{
			$this->disconnect();

			return false;
		}
	}


}


?>