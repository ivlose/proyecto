<a href="indice.php?action=registro"><IMG class="user"SRC="vista/img/user.png"></a>
 
