<div id="contenedor">    
<a href="indice.php?action=registro"><IMG class="user" alt="Formulario Registro" SRC="vista/img/user.png"></a>  
<a href="indice.php?action=perfil"><input type="submit" value="perfil" id="botonPerfil"></a>
<a href="indice.php?action=equipos"><input type="submit" value="equipos" id="botonPerfil"></a>
</div>
 
