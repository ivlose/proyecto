<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img src="vista/img/minecraft4.jpg" alt="MINECRAFT">
          <div class="carousel-caption">   
          <h3></h3>      
        </div>
      </div>

        <div class="item">
          <img src="vista/img/minecraf2t.jpg" alt="MINECRAFT">
        <div class="carousel-caption"> 
        <h3></h3>        
          </div>
            </div>

    <div class="item">
      <img src="vista/img/minecraft3.jpg" alt="MINECRAFT">
      <div class="carousel-caption">
        <h3></h3>
      </div>
    </div>
<div class="item">
      <img src="vista/img/minecraft.jpg" alt="MINECRAFT">
      <div class="carousel-caption">
        <h3></h3>
      </div>
</div>

    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

<div id="contenedor">
<div id="contenido-caja">COMPETICIONES
<p>HOLA ESTO SON LAS COMPETICIONES</p></div>
<div id="contenido-caja2">NOTICIAS
<P>ESTO SON LAS NOTICIAS DE LAS 3</P></div>
<div id="contenido-caja3">
<b>TOP 10</b>
 <UL id="lista">
<LI STYLE="list-style-image: url(vista/img/oro.png)"> GIANTS
<LI STYLE="list-style-image: url(vista/img/plata.png)"> PAIN GAMING
<LI STYLE="list-style-image: url(vista/img/bronze.png)"> GBOTS
</ul>
<hr id="linea" />
<ol class="espacio">
<li value="4">Este será el número 4. </li>
<li class="espacio">Este será el 5. </li>
<li class="espacio"> Este será el 6</li>
<li class="espacio"> Este será el 7</li>
<li class="espacio"> Este será el 8</li>
<li class="espacio"> Este será el 9</li>
<li class="espacio"> Este será el 10</li>
</ol>

<b>TOP 10 SPECIAL PRO LEAGUE</b>

</div>

</div>
