<form action="indice.php" method="post">
     <table border="0" cellspacing="4" cellpadding="0" class="tabla">
  <tr>
    <td>Insertar: </td>
    <td><label>
      Nick: <input type="text" name="nick" autofocus required />
    </label></td>
    <td><label>
      Nombre: <input type="text" name="nombre" autofocus required />
    </label></td>
    <td><label>
      Apellido: <input type="text" name="apellido" autofocus required />
    </label></td>
    <td><label>
      Email: <input type="text" name="email" autofocus required />
    </label></td>
    <td><label>
      Contraseña: <input type="password" name="contrasenya" autofocus required />
    </label></td>
     <td><label>
      Confirmar contraseña: <input type="password" name="contrasenya2" autofocus required />
    </label></td>
    <td><label>
      <input type="submit" name="Submit" value="   Insertar   " />
    </label></td>
  </tr>
</table>
</form>